outlets = 1;


var irL = new Buffer("ir_L");
var irR = new Buffer("ir_R");
var ir1 = new Buffer("ir1");
numSamples = 200;

var elevationBuffer = new Buffer("elevations");
NUM_ELEVATIONS = 26;

var azimuthBuffer = new Buffer("azimuths");
NUM_AZIMUTHS = 50;


function loadbang() 
{
	initElevationBuffer();
	initAzimuthBuffer();
}	


function bang() {
	post("Channels: " + ir1.channelcount() + '\n');
	post("Frames (samples): " + ir1.framecount() + '\n');
	post("Length (in ms): " + ir1.length() + '\n');
}

function initElevationBuffer() 
{
	startPos = -50.625;
	step = 5.625
	for (var i = 0; i < NUM_ELEVATIONS; i++) 
	{
		e = i*step + startPos;
		elevationBuffer.poke(1,i,e);
	}
}

function initAzimuthBuffer() 
{
	for (var i = 0; i < NUM_AZIMUTHS; i++) 
	{
		azValue = AZIMUTH_POSITIONS[i]
		azimuthBuffer.poke(1,i,azValue);
	}
}



ELEVATION_POSITIONS=
[
	-50.6250000000000,
	-45,
	-39.3750000000000,
	-33.7500000000000,
	-28.1250000000000,
	-22.5000000000000,
	-16.8750000000000,
	-11.2500000000000,
	-5.62500000000000,
	0,
	5.62500000000000,
	11.2500000000000,
	16.8750000000000,
	22.5000000000000,
	28.1250000000000,
	33.7500000000000,
	39.3750000000000,
	45,
	50.6250000000000,
	56.2500000000000,
	61.8750000000000,
	67.5000000000000,
	73.1250000000000,
	78.7500000000000,
	84.3750000000000,
	90
]

AZIMUTH_POSITIONS=
[
	-180,
	-175,
	-170,
	-165,
	-160,
	-155,
	-150,
	-145,
	-140,
	-135,	
	-125,	
	-115,	
	-100,	
	-80,
	-65,
	-55,
	-45,
	-40,
	-35,
	-30,
	-25,
	-20,
	-15,	
	-10,	
	-5,	
	0,	
	5,	
	10,	
	15,	
	20,	
	25,	
	30,	
	35,	
	40,	
	45,	
	55,	
	65,	
	80,	
	100,	
	115,	
	125,	
	135,	
	140,	
	145,	
	150,	
	155,	
	160,	
	165,	
	170,	
	175
]



function getAllElevations()
{
	elevations = [];
	startPos = -50.625;
	step = 5.625
	for (var i = 0; i < NUM_ELEVATIONS; i++) {
		elevations[i] = elevations[i] * step + startPos;
	}
	return elevations;
}

function getAllAzimuths() 
{
	azimuths = [];
	startPos = -180;
	step1 = 5;
	breakPoint1 = (180-135)/step;
	for (var i = 0; i < breakPoint1; i++) {
		azimuths[i] = startPos + i*step1;
	}

	return azimuths;
}


	
//returns the filename of the impulse response (from subject 52), given azmiuth and elevation.
//if an invalid azmiuth/elevation is given, it is rounded to the nearest valid entry
function getFileName(azmiuth, elevation)
{
	subjectId = "S052"
	
	azVal = azmiuth.toFixed(6);
	elVal = elevation.toFixed(6);
	
	filename = [subjectId,"_","Az",azVal,"_El",elVal,".wav"].join("")
	
	outlet(0,filename);
}


function addVars(num1,num2) 
{
	return num1+num2;
}
	