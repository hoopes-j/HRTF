// inlets and outlets
inlets = 1
outlets = 1
// global variables
var val = 0;
// initialize state array
var state = new Array(8)
for (var i = 0; i < 8; i++) {
  state[i] = new Array(8)
  for (var j = 0; j < 8; j++) {
    state[i][j] = 0
  }
}
// set up jsui defaults to 2d
sketch.default2d()
// initialize graphics
draw()
refresh()


function bang()
{
  draw();
  refresh();
  outlet(0,val);
}

function setvalueof(v)
{
  msg_float(v);
}

function msg_float(v)
{
  val = v;
  notifyclients();
  bang();
}


// draw -- main graphics function
function draw() {
  with (sketch) {
    // set how the polygons are rendered
    glclearcolor(1, 0, 0, 0) // set the clear color
    glclear() // erase the background
  var theta = val*(2*Math.PI);
  x = .8*Math.sin(theta);
  y = .8*Math.cos(theta);
  post("\n")
  post(val,theta,x,y);
  moveto(x,y,0);
  glcolor(1, 0, 0, 1);
  circle(.1) // draw the circle
  }
}
